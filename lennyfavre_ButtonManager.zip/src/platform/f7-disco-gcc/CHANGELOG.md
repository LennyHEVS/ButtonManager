
# Changelog

## 0.2.1 - (2019-04-25)
- Added BUTTONSCONTROLLER_EXCLUDE_FROM_BUILD define to exclude ButtonsController from build

## 0.2.0 - (2019-04-25)
- Added ButtonsController class (originally from ButtonManager project)
- Added C functions to trace package

## 0.1.0 - (2019-04-25)
- Moved project from SVN repository to GIT repository. 
  Took code from Realtime Oscilloscope project.
