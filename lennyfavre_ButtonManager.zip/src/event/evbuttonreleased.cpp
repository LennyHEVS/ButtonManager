#include "events.h"
#include "event/evbuttonreleased.h"

evButtonReleased::evButtonReleased() :
    XFCustomEvent(evButtonReleasedId)
{

}
