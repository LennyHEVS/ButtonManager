#ifndef EVBUTTONRELEASED_H
#define EVBUTTONRELEASED_H

#include "xf/customevent.h"
#include "events.h"

class evButtonReleased : public XFCustomEvent
{
public:
    evButtonReleased();
};

#endif // EVBUTTONRELEASED_H
