#include "events.h"
#include "evbuttonpressed.h"

evButtonPressed::evButtonPressed() :
    XFCustomEvent(evButtonPressedId)
{

}
