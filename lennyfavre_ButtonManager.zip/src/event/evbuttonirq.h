#ifndef EVBUTTONIRQ_H
#define EVBUTTONIRQ_H

#include "xf/customevent.h"
#include "events.h"

class evButtonIrq : public XFCustomEvent
{
public:
	evButtonIrq();
};

#endif // EVBUTTONIRQ_H
