#ifndef XF_CONFIG_DEFAULT_H
#define XF_CONFIG_DEFAULT_H

#warning "You should provide your own 'xf-config.h' file in your project!"

// If you need some inspiration on what to provide in the 'xf-config.h' file 
// please have a look onto the 'xf-config.h' files provided in the 
// XF test-bench tests.

#endif // XF_CONFIG_DEFAULT_H
