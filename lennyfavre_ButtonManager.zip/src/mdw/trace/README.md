# trace

Trace package with interface definition.

The implementation of the Trace package is platform specific.

Every platform must provide its own implementation of the Trace package.